package com.example.acosta_ashl.finalproject;

import android.content.Intent;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


import java.util.Arrays;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        final Button homeButton  = (Button) findViewById(R.id.homeButton);
        final Context context = this;
        View.OnClickListener listenerOne = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(context, MainActivity.class);
                startActivity(intent1);

            };
        };
        homeButton.setOnClickListener(listenerOne);
    }


    @Override
    public void onMapReady( GoogleMap googleMap ) {
        mMap = googleMap;

        LatLng burlington = new LatLng(42.508045, -71.197929);
        mMap.addMarker(new MarkerOptions().position(burlington).title("Location in Burlington"));
        LatLng natick = new LatLng(42.3008, -71.3841);
        mMap.addMarker(new MarkerOptions().position(natick).title("Location in Natick"));
        LatLng waltham = new LatLng(42.3765, -71.2356);
        mMap.addMarker(new MarkerOptions().position(waltham).title("Location in Waltham"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(waltham, 10));


    }
}
