package com.example.acosta_ashl.finalproject;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.EditText;
import java.io.File;
import java.io.*;
import android.util.Log;
import java.io.OutputStreamWriter;
import android.widget.ArrayAdapter;

public class Sizing extends Activity {
    /*private ArrayList<String> sizingInformation;
    */
    public static TextToSpeech toSpeech;
    final Context context = this;

    EditText sizingHeight;
    EditText sizingWeight;
    EditText sizingShoeSize;
    EditText sizingInseam;
    EditText sizingOutseam;
    EditText sizingHip;
    EditText sizingWaist;
    EditText sizingNeck;
    EditText sizingSleeve;
    EditText sizingChest;
    EditText sizingTorso;
    Button continueButton;
    Spinner spinner;
    public String height;
    public String weight;
    public String shoeSize;
    public String inseam;
    public String outseam;
    public String hip;
    public String waist;
    public String neck;
    public String chest;
    public String sleeve;
    public String torso;


    private static final String[]tuxedos = {"Blue Tuxedo", "Purple Tuxedo", "Black Tuxedo", "White Tuxedo"};

    Button checkOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sizing);

        ActionBar actionBar = getActionBar();          //create ActionBar object
        actionBar.setDisplayShowTitleEnabled(true);

        sizingHeight = (EditText) findViewById(R.id.heightN);
        sizingWeight = (EditText) findViewById(R.id.weightN);
        sizingShoeSize = (EditText) findViewById(R.id.shoeN);
        sizingInseam = (EditText) findViewById(R.id.inseamN);
        sizingOutseam = (EditText) findViewById(R.id.outseamN);
        sizingHip = (EditText) findViewById(R.id.hipN);
        sizingWaist = (EditText) findViewById(R.id.waistN);
        sizingNeck = (EditText) findViewById(R.id.neckN);
        sizingSleeve = (EditText) findViewById(R.id.sleeveN);
        sizingChest = (EditText) findViewById(R.id.chestN);
        sizingTorso = (EditText) findViewById(R.id.torsoN);
        spinner= (Spinner) findViewById(R.id.spinner);
        continueButton = (Button) findViewById(R.id.continueButton);


        ArrayAdapter<String>adapter = new ArrayAdapter<String>(Sizing.this,
                android.R.layout.simple_spinner_item,tuxedos);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        continueButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                height = sizingHeight.getText().toString();
                weight = sizingWeight.getText().toString();
                shoeSize = sizingShoeSize.getText().toString();
                inseam = sizingInseam.getText().toString();
                outseam = sizingOutseam.getText().toString();
                hip = sizingHip.getText().toString();
                waist = sizingWaist.getText().toString();
                neck = sizingNeck.getText().toString();
                chest = sizingChest.getText().toString();
                sleeve = sizingSleeve.getText().toString();
                torso = sizingTorso.getText().toString();

                File directory = getFilesDir();
                File myFile = new File(directory, "SizingInformation.txt");

                try {
                    myFile.createNewFile();
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("SizingInformation.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.write("Height: " + height);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Weight: " + weight);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Shoe Size: " + shoeSize);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Inseam: " + inseam);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Outseam: " + outseam);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Hip: " + hip);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Waist: " + waist);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Neck: " + neck);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Sleeve: " + sleeve);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Chest: " + chest);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Torso: " + torso);
                    outputStreamWriter.close();
                    Toast.makeText(getBaseContext(),
                            "sizing information saved" + getFilesDir() + "/" + myFile,
                            Toast.LENGTH_SHORT).show();
                }
                catch (IOException e) {
                    Log.e("Exception", "File write failed: " + e.toString());
                }

                Intent intent6 = new Intent(context, personalForm.class);
                startActivity(intent6);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final Context context = this;
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.home:
                Intent intent1 = new Intent(context, MainActivity.class);
                startActivity(intent1);
                toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    public void onInit(int status) {
                        toSpeech.speak("Taking you to the homepage", TextToSpeech.QUEUE_FLUSH, null);

                    }
                });
                return true;

            case R.id.products:
                Intent intent2 = new Intent(context, selection.class);
                startActivity(intent2);
                return true;

            case R.id.contact:
                Intent intent3 = new Intent(context, contactUs.class);
                startActivity(intent3);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
