package com.example.acosta_ashl.finalproject;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;

public class contactUs extends Activity {

    public static TextToSpeech toSpeech;
    private ArrayList<String> arrayList;
    private ArrayAdapter<String> adapter;
    private EditText editText;
    private int itemPosition;
    private TextView contactPhoneN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        ActionBar actionBar = getActionBar();          //create ActionBar object
        actionBar.setDisplayShowTitleEnabled(true);

        final ListView listView = (ListView) findViewById(R.id.aList);
        final String[] items = {"Burlington", "Natick", "Waltham"};
        arrayList = new ArrayList<>(Arrays.asList(items));
        adapter = new ArrayAdapter<String>(this,R.layout.list_item, R.id.txtitem, arrayList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(contactUs.this, MapActivity.class);
                intent.putExtra("Location", listView.getItemAtPosition(position).toString());
                startActivity(intent);

            }
        });

        contactPhoneN = (TextView) findViewById(R.id.contactPhoneN);

        contactPhoneN.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                    Intent intent = new Intent("android.intent.action.DIAL");
                    intent.setData(Uri.parse("tel:7818912000"));
                    startActivity(intent);
                }
            });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final Context context = this;
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.home:
                Intent intent1 = new Intent(context, MainActivity.class);
                startActivity(intent1);
                toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    public void onInit(int status) {
                        toSpeech.speak("Taking you to the homepage", TextToSpeech.QUEUE_FLUSH, null);

                    }
                });
                return true;


            case R.id.products:
                Intent intent2 = new Intent(context, selection.class);
                startActivity(intent2);
                return true;

            case R.id.contact:
                Intent intent3 = new Intent(context, contactUs.class);
                startActivity(intent3);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}