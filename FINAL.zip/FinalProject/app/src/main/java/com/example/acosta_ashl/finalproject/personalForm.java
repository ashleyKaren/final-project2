package com.example.acosta_ashl.finalproject;

import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;

public class personalForm extends Activity {

    public static TextToSpeech toSpeech;

    private ArrayList<String> customerInformation;
    public static final String FILE_NAME ="customer_information.txt";

    Button purchase;
    EditText cEmail;
    EditText cName;
    EditText cPhone;
    EditText cCreditNumber;
    EditText cCreditName;
    EditText cCreditAddress;
    EditText cCVV;
    public String name;
    public String phone;
    public String email;
    public String creditAddress;
    public String creditNumber;
    public String creditName;
    public String cvv;

    final Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_form);

        cEmail = (EditText) findViewById(R.id.cEmail);

        purchase = (Button) findViewById(R.id.purchase);

        cName = (EditText) findViewById(R.id.cName);
        cEmail = (EditText) findViewById(R.id.cEmail);
        cPhone = (EditText) findViewById(R.id.cPhone);
        cCreditAddress = (EditText) findViewById(R.id.cCreditAddress);
        cCreditNumber = (EditText) findViewById(R.id.cCreditNumber);
        cCreditName =  (EditText) findViewById(R.id.cCreditName);
        cCVV = (EditText) findViewById(R.id.cCVV);

        final String[] items = {String.valueOf(cName), String.valueOf(cEmail),
                String.valueOf(cPhone), String.valueOf(cCreditNumber),
                String.valueOf(cCreditName), String.valueOf(cCreditAddress), String.valueOf(cCVV)};
        customerInformation = new ArrayList<>(Arrays.asList(items));


        purchase.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                name = cName.getText().toString();
                email = cEmail.getText().toString();
                phone = cPhone.getText().toString();
                creditAddress = cCreditAddress.getText().toString();
                creditNumber = cCreditNumber.getText().toString();
                creditName = cCreditName.getText().toString();
                cvv = cCVV.getText().toString();

                Intent intent6 = new Intent(context, thankyou.class);
                startActivity(intent6);

                File directory = getFilesDir();
                File myFile = new File(directory, "list.txt");

                try {
                    myFile.createNewFile();
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("SizingInformation.txt", Context.MODE_APPEND));
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Name: " + name);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Email: " + email);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Phone: " + phone);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Credit Address: " + creditAddress);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Credit Number: " + creditNumber);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("Credit Name: " + creditName);
                    outputStreamWriter.write("\n");
                    outputStreamWriter.write("CVV: " + cvv);
                    outputStreamWriter.close();
                    Toast.makeText(getBaseContext(),
                            "sizing information saved" + getFilesDir() + "/" + myFile,
                            Toast.LENGTH_SHORT).show();
                }
                catch (IOException e) {
                    Log.e("Exception", "File write failed: " + e.toString());
                }

            }
            });
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final Context context = this;
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.home:
                Intent intent1 = new Intent(context, MainActivity.class);
                startActivity(intent1);
                toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    public void onInit(int status) {
                        toSpeech.speak("Taking you to the homepage", TextToSpeech.QUEUE_FLUSH, null);

                    }
                });
                return true;


            case R.id.products:
                Intent intent2 = new Intent(context, selection.class);
                startActivity(intent2);
                return true;

            case R.id.contact:
                Intent intent3 = new Intent(context, contactUs.class);
                startActivity(intent3);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

}

