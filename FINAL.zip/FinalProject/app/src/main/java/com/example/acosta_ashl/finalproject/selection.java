package com.example.acosta_ashl.finalproject;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class selection extends Activity {

    private ImageView tuxedo1;
    private ImageView tuxedo2;
    private ImageView tuxedo3;
    private ImageView tuxedo4;

    public static TextToSpeech toSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        ActionBar actionBar = getActionBar();          //create ActionBar object
        actionBar.setDisplayShowTitleEnabled(true);

        tuxedo1 = (ImageView) findViewById(R.id.tuxedo1);
        tuxedo2 = (ImageView) findViewById(R.id.tuxedo2);
        tuxedo3 = (ImageView) findViewById(R.id.tuxedo3);
        tuxedo4 = (ImageView) findViewById(R.id.tuxedo4);

        final Context context = this;

        tuxedo4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(context, Sizing.class);
                startActivity(intent);
            }

        });

        tuxedo3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(context, Sizing.class);
                startActivity(intent);
            }

        });

        tuxedo2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(context, Sizing.class);
                startActivity(intent);
            }

        });

        tuxedo1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(context, Sizing.class);
                startActivity(intent);
            }

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final Context context = this;
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.home:
                Intent intent1 = new Intent(context, MainActivity.class);
                startActivity(intent1);
                toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                    public void onInit(int status) {
                        toSpeech.speak("Taking you to the homepage", TextToSpeech.QUEUE_FLUSH, null);

                    }
                });
                return true;


            case R.id.products:
                Intent intent2 = new Intent(context, selection.class);
                startActivity(intent2);
                return true;


            case R.id.contact:
                Intent intent4 = new Intent(context, contactUs.class);
                startActivity(intent4);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
