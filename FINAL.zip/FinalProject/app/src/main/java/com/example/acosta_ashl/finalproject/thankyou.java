package com.example.acosta_ashl.finalproject;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.app.NotificationChannel;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.graphics.Color;
import android.support.v4.app.NotificationCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.app.Activity;
import android.view.View.OnClickListener;

public class thankyou extends Activity {

    public static TextToSpeech toSpeech;
    Button thankYouButton;


    final Context context = this;

    private NotificationManager mNotificationManager;
    private Notification notifyDetails;
    private int SIMPLE_NOTIFICATION_ID;
    private String contentTitle = "Notification";
    private String contentText = "Confirmation of order";

    //CRASHES


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thankyou);

        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        notifyDetails =
                new Notification.Builder(this)
                        .setContentTitle(contentTitle)   //set Notification text and icon
                        .setContentText(contentText)


                        .setWhen(System.currentTimeMillis())    //timestamp when event occurs

                        .setAutoCancel(true)     //cancel Notification after clicking on it

                        //set Android to vibrate when notified
                        .setVibrate(new long[]{1000, 1000, 1000, 1000})

                        // flash LED (color, on in millisec, off)
                        //doesn't work for all handsets
                        .setLights(Integer.MAX_VALUE, 500, 500)

                        .build();


        thankYouButton = (Button) findViewById(R.id.thankYouButton);

        thankYouButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                notificationcall();

            }
        });
    }

    public void notificationcall(){

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "App Notifications", NotificationManager.IMPORTANCE_HIGH);

            // Configure the notification channel.
            notificationChannel.setDescription("Channel description");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);

        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.tuxedo2)
                .setContentTitle("Notification from Delux Tux")
                .setContentText("Your order was received. Thank you!")
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.tuxedo2));

        notificationManager.notify(/*notification id*/1, notificationBuilder.build());
    }

        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            getMenuInflater().inflate(R.menu.menu, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            final Context context = this;
            // Handle item selection
            switch (item.getItemId()) {
                case R.id.home:
                    Intent intent1 = new Intent(context, MainActivity.class);
                    startActivity(intent1);
                    toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                        public void onInit(int status) {
                            toSpeech.speak("Taking you to the homepage", TextToSpeech.QUEUE_FLUSH, null);

                        }
                    });
                    return true;

                case R.id.products:
                    Intent intent2 = new Intent(context, selection.class);
                    startActivity(intent2);
                    return true;

                case R.id.contact:
                    Intent intent3 = new Intent(context, contactUs.class);
                    startActivity(intent3);
                    return true;


                default:
                    return super.onOptionsItemSelected(item);
            }
        }
    }

